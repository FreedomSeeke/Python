# simple_calculator

运行方式：
```bash
pip install -r requirements.txt
python manage.py runserver
```
