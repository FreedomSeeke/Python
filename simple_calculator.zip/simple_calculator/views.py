from django.shortcuts import render
import math
import random

def calculator(request):
    result = ''
    if request.method == 'POST':
        op1 = request.POST.get('operand1', '')
        op2 = request.POST.get('operand2', '')
        operator = request.POST.get('operator', '')

        try:
            if operator == 'π':
                result = math.pi
            elif operator == 'random':
                result = random.random()
            elif operator == 'abs':
                result = abs(float(op1))
            elif operator == '√':
                result = math.sqrt(float(op1))
            elif operator == 'sin':
                result = math.sin(float(op1))
            elif operator == 'cos':
                result = math.cos(float(op1))
            elif operator == 'log':
                result = math.log(float(op1))
            elif operator == 'floor':
                result = math.floor(float(op1))
            elif operator == 'ceil':
                result = math.ceil(float(op1))
            elif operator == '+':
                result = float(op1) + float(op2)
            elif operator == '-':
                result = float(op1) - float(op2)
            elif operator == '*':
                result = float(op1) * float(op2)
            elif operator == '/':
                result = float(op1) / float(op2)
            elif operator == '^':
                result = float(op1) ** float(op2)
            elif operator == '%':
                result = float(op1) * 0.01
            else:
                result = '未知运算符'
        except Exception as e:
            result = f"错误: {e}"

    return render(request, 'index.html', {'result': result})
